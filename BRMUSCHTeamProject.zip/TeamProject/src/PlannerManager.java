import java.util.ArrayList;

public class PlannerManager {
    private ArrayList<Course> courses;
    private ArrayList<Assignment> assignments;
    
    public PlannerManager() {
        courses = new ArrayList<Course>();
        assignments = new ArrayList<Assignment>();
    }
    
    public Course createCourse(String courseName, String courseCode, 
            String profName, String schedule) {
        Course course = Course.createCourse(courseName, courseCode, profName, 
                schedule);
        if (course != null) {
            courses.add(course);
        }
        return course;
    }
    
    public Assignment addAssignment(String assignmentName, 
            Course assignedCourse, String dueDate, String priority,
            String description) {
        Assignment assignment = Assignment.addAssignment(assignmentName, 
                assignedCourse, dueDate, priority, description);
        if(assignment != null) {
            assignments.add(assignment);
        }
        return assignment;
    }
    
    public void deleteAssignment(Assignment assignment) {
        assignment.deleteAssignment();
        assignments.remove(assignment);
    }
    
    public void displayAssignments() {
        for (int i = 0; i < assignments.size(); i++) {
            System.out.println(assignments.get(i));
        }
    }
    
    public void updateDashboard() {
        int totalCourses = courses.size();
        int totalAssignments = assignments.size();
        int completed = 0;
        
        for (int i = 0; i < assignments.size(); i++) {
            if (assignments.get(i).getIsComplete()) {
                completed = completed + 1;
            }
        }
        
        System.out.println("Total Courses: " + totalCourses);
        System.out.println("Total Assignments: " + totalAssignments);
        System.out.println("Completed Assignments: " + completed);
    }
    
    public ArrayList<Course> getCourses() {
        return courses;
    }
    
    public ArrayList<Assignment> getAssignments() {
        return assignments;
    }
    
}