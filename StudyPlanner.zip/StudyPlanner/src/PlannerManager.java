/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Jamal Shipman
 */

import java.util.ArrayList;
import javax.swing.DefaultListModel;

public class PlannerManager {
    private ArrayList<Course> courseList = new ArrayList<>();
    private ArrayList<Assignment> assignmentList = new ArrayList<>();

    public void addCourse(Course c) { courseList.add(c); }
    public void addAssignment(Assignment a) { assignmentList.add(a); }
    
    // --- UPDATED: Now accepts the boolean status ---
    public void editAssignment(int index, String newName, String newDate, String newPriority, boolean isDone) {
        if (index >= 0 && index < assignmentList.size()) {
            Assignment a = assignmentList.get(index);
            a.editAssignment(newName, newDate, newPriority);
            a.setIsComplete(isDone);
        }
    }

    public void deleteAssignment(int index) {
        if (index >= 0 && index < assignmentList.size()) {
            assignmentList.remove(index);
        }
    }

    // --- UPDATED: Now toggles the status instead of just forcing it to true ---
    public void toggleAssignmentComplete(int index) {
        if (index >= 0 && index < assignmentList.size()) {
            assignmentList.get(index).toggleComplete();
        }
    }

    public ArrayList<Course> getCourses() { return courseList; }
    public ArrayList<Assignment> getAssignments() { return assignmentList; }

    public void displayAssignments(DefaultListModel<String> listModel) {
        listModel.clear();
        for (Assignment a : assignmentList) {
            listModel.addElement(a.toString());
        }
    }

    public String updateDashboard() {
        return "Courses Tracked: " + courseList.size() + " | Total Tasks: " + assignmentList.size();
    }

    // --- SORTING METHODS ---

    public void sortByName() {
        assignmentList.sort((a1, a2) -> a1.getAssignmentName().compareToIgnoreCase(a2.getAssignmentName()));
    }

    public void sortByDate() {
        assignmentList.sort((a1, a2) -> a1.getDueDate().compareToIgnoreCase(a2.getDueDate()));
    }

    public void sortByPriority() {
        assignmentList.sort((a1, a2) -> getPriorityWeight(a1.getPriority()) - getPriorityWeight(a2.getPriority()));
    }

    private int getPriorityWeight(String priority) {
        if (priority.equalsIgnoreCase("High")) return 1;
        if (priority.equalsIgnoreCase("Medium")) return 2;
        if (priority.equalsIgnoreCase("Low")) return 3;
        return 4; 
    }
}
