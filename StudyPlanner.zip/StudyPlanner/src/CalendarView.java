/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author shane
 */

import javax.swing.*;
import java.awt.*;

public class CalendarView extends JPanel {
    private JLabel monthLabel;

    public CalendarView() {
        setLayout(new BorderLayout());
        monthLabel = new JLabel("Calendar View Active", SwingConstants.CENTER);
        monthLabel.setFont(new Font("Arial", Font.BOLD, 18));
        add(monthLabel, BorderLayout.CENTER);
    }

    public void displayCalendar() { }
    public void moveMonth(boolean forward) { }
}
