/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Brandon Musch
 */

public class Course {
    private String courseName;
    private String courseCode;
    private String profName;
    private String schedule;

    public Course(String name, String code, String prof, String sched) {
        this.courseName = name;
        this.courseCode = code;
        this.profName = prof;
        this.schedule = sched;
    }

    public static Course createCourse(String name, String code, String prof, String sched) {
        return new Course(name, code, prof, sched);
    }

    public void editCourse(String name, String code, String prof, String sched) {
        this.courseName = name;
        this.courseCode = code;
        this.profName = prof;
        this.schedule = sched;
    }

    public String getCourseCode() { return courseCode; }
    public String getCourseName() { return courseName; }
    public String getProfName() { return profName; }
    public String getSchedule() { return schedule; }
}
