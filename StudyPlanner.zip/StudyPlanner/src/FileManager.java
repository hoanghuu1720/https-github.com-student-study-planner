/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author shane
 */

import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.Scanner;

public class FileManager {
    private final String FILE_NAME = "planner_data.txt";

    public void saveData(PlannerManager manager) throws Exception {
        PrintWriter writer = new PrintWriter(new FileWriter(FILE_NAME));
        
        // Using semi-colon instead of comma just in case users type a comma in their assignment name!
        for (Course c : manager.getCourses()) {
            writer.println("C;" + c.getCourseName() + ";" + c.getCourseCode() + ";" + c.getProfName() + ";" + c.getSchedule());
        }
        for (Assignment a : manager.getAssignments()) {
            writer.println("A;" + a.getAssignmentName() + ";" + a.getAssignedCourse().getCourseCode() + ";" + a.getDueDate() + ";" + a.getPriority() + ";" + a.getIsComplete());
        }
        writer.close();
    }

    public void loadData(PlannerManager manager) throws Exception {
        File file = new File(FILE_NAME);
        if (!file.exists()) return; // If there is no save file yet, do nothing

        Scanner scanner = new Scanner(file);
        manager.getCourses().clear();
        manager.getAssignments().clear();

        while (scanner.hasNextLine()) {
            String[] p = scanner.nextLine().split(";");
            if (p[0].equals("C") && p.length == 5) {
                manager.addCourse(Course.createCourse(p[1], p[2], p[3], p[4]));
            } else if (p[0].equals("A") && p.length == 6) {
                // Find the matching course object to attach to the assignment
                Course matchedCourse = null;
                for (Course c : manager.getCourses()) {
                    if (c.getCourseCode().equals(p[2])) {
                        matchedCourse = c;
                        break;
                    }
                }
                if (matchedCourse != null) {
                    Assignment loaded = Assignment.addAssignment(p[1], matchedCourse, p[3], p[4]);
                    if (p[5].equals("true")) {
                        loaded.markComplete();
                    }
                    manager.addAssignment(loaded);
                }
            }
        }
        scanner.close();
    }
}
