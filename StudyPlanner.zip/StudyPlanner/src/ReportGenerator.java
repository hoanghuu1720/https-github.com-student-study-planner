/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author shane
 */

import java.util.ArrayList;

public class ReportGenerator {
    
    public double calculateCompletion(ArrayList<Assignment> assignments) {
        if (assignments.isEmpty()) return 0.0;
        
        int completedCount = 0;
        for (Assignment a : assignments) {
            if (a.getIsComplete()) {
                completedCount++;
            }
        }
        return ((double) completedCount / assignments.size()) * 100;
    }

    public String generateReport(ArrayList<Assignment> assignments) {
        double rate = calculateCompletion(assignments);
        return String.format("=== Student Progress Report ===\nTotal Assignments: %d\nCompletion Rate: %.1f%%", assignments.size(), rate);
    }
}
