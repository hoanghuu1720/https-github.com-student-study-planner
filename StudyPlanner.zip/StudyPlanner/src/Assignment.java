/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Brandon Musch
 */

public class Assignment {
    private String assignmentName;
    private final Course assignedCourse;
    private String dueDate;
    private String priority;
    private boolean isComplete;

    public Assignment(String name, Course course, String date, String priority) {
        this.assignmentName = name;
        this.assignedCourse = course;
        this.dueDate = date;
        this.priority = priority;
        this.isComplete = false;
    }

    public static Assignment addAssignment(String name, Course course, String date, String priority) {
        return new Assignment(name, course, date, priority);
    }

    public void editAssignment(String name, String date, String priority) {
        this.assignmentName = name;
        this.dueDate = date;
        this.priority = priority;
    }

    // --- COMPLETION METHODS ---
    
    // The specific method PlannerManager is looking for!
    public void markComplete() { 
        this.isComplete = true; 
    }

    // The advanced methods for your checkbox/toggle feature
    public void setIsComplete(boolean status) {
        this.isComplete = status;
    }
    
    public void toggleComplete() {
        this.isComplete = !this.isComplete;
    }

    // --- GETTERS ---
    public String getAssignmentName() { return assignmentName; }
    public Course getAssignedCourse() { return assignedCourse; }
    public String getDueDate() { return dueDate; }
    public String getPriority() { return priority; }
    public boolean getIsComplete() { return isComplete; }
    
    @Override
    public String toString() {
        String status = isComplete ? "[DONE]" : "[PENDING]";
        return status + " " + assignmentName + " (" + assignedCourse.getCourseCode() + ") - Due: " + dueDate + " [" + priority + "]";
    }
}
