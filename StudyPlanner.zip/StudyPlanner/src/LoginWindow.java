/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Shane Mathis
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LoginWindow extends JFrame {
    private JTextField userField;
    private JPasswordField passField;

    public LoginWindow() {
        setTitle("Study Planner - Login");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(4, 1));

        userField = new JTextField(10);
        passField = new JPasswordField(10);
        JButton loginBtn = new JButton("Login");

        JPanel panel = new JPanel();
        panel.add(new JLabel("User:"));
        panel.add(userField);
        panel.add(new JLabel("Pass:"));
        panel.add(passField);

        add(new JLabel("Student Study Planner", SwingConstants.CENTER));
        add(panel);
        add(loginBtn);

        loginBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (validateLogin(userField.getText(), new String(passField.getPassword()))) {
                    // Start the application data manager
                    PlannerManager manager = new PlannerManager();
                    
                    // Launch the Main GUI
                    StudyPlannerGUI mainGUI = new StudyPlannerGUI(manager);
                    mainGUI.setVisible(true);
                    
                    dispose(); // Closes the login window
                } else {
                    JOptionPane.showMessageDialog(null, "Invalid Login. Try user: admin, pass: 1234");
                }
            }
        });
    }

    public boolean validateLogin(String user, String pass) {
        return user.equals("admin") && pass.equals("1234");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new LoginWindow().setVisible(true);
            }
        });
    }
}
