/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Shane Mathis
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class StudyPlannerGUI extends JFrame {
    private PlannerManager manager;
    private FileManager fileManager;
    private ReportGenerator reportGenerator;
    
    private DefaultListModel<String> listModel;
    private JList<String> assignmentUIList;
    private JLabel dashboardLabel;
    private JComboBox<String> sortDropdown;

    public StudyPlannerGUI(PlannerManager manager) {
        this.manager = manager;
        this.fileManager = new FileManager();
        this.reportGenerator = new ReportGenerator();
        
        setTitle("Student Study Planner");
        setSize(750, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Setup the Data List
        listModel = new DefaultListModel<>();
        assignmentUIList = new JList<>(listModel);
        assignmentUIList.setFont(new Font("Monospaced", Font.PLAIN, 14));
        add(new JScrollPane(assignmentUIList), BorderLayout.CENTER);

        // --- TOP PANEL (Dashboard + Sorting) ---
        JPanel topPanel = new JPanel(new BorderLayout());
        dashboardLabel = new JLabel(manager.updateDashboard(), SwingConstants.CENTER);
        dashboardLabel.setFont(new Font("Arial", Font.BOLD, 16));
        dashboardLabel.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
        topPanel.add(dashboardLabel, BorderLayout.CENTER);

        String[] sortOptions = {"Sort Tasks By...", "Alphabetical (Name)", "Due Date", "Priority (High-Low)"};
        sortDropdown = new JComboBox<>(sortOptions);
        topPanel.add(sortDropdown, BorderLayout.EAST);
        add(topPanel, BorderLayout.NORTH);

        // --- BOTTOM PANEL (Buttons) ---
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(2, 4, 5, 5));
        
        JButton btnAdd = new JButton("Add Task");
        JButton btnEdit = new JButton("Edit Task"); 
        JButton btnToggle = new JButton("Toggle Status"); // UPDATED BUTTON
        JButton btnDelete = new JButton("Delete Task");
        JButton btnReport = new JButton("Progress Report");
        JButton btnSave = new JButton("Save Data");
        JButton btnLoad = new JButton("Load Data");

        buttonPanel.add(btnAdd);
        buttonPanel.add(btnEdit);
        buttonPanel.add(btnToggle);
        buttonPanel.add(btnDelete);
        buttonPanel.add(btnReport);
        buttonPanel.add(btnSave);
        buttonPanel.add(btnLoad);
        add(buttonPanel, BorderLayout.SOUTH);

        // --- BUTTON ACTION LISTENERS ---

        sortDropdown.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int choice = sortDropdown.getSelectedIndex();
                if (choice == 1) manager.sortByName();
                else if (choice == 2) manager.sortByDate();
                else if (choice == 3) manager.sortByPriority();
                refreshScreen();
            }
        });

        btnAdd.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (manager.getCourses().isEmpty()) {
                    manager.addCourse(Course.createCourse("Intro to OOP", "CSCI 325", "Prof. Henderson", "Summer"));
                }
                showTaskForm(null, -1); 
            }
        });

        btnEdit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int index = assignmentUIList.getSelectedIndex();
                if (index != -1) {
                    Assignment selectedTask = manager.getAssignments().get(index);
                    showTaskForm(selectedTask, index); 
                } else {
                    JOptionPane.showMessageDialog(null, "Please select a task to edit!");
                }
            }
        });

        btnToggle.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int index = assignmentUIList.getSelectedIndex();
                if (index != -1) {
                    manager.toggleAssignmentComplete(index); // Flips the status back and forth
                    refreshScreen();
                } else {
                    JOptionPane.showMessageDialog(null, "Please click on a task first!");
                }
            }
        });

        btnDelete.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int index = assignmentUIList.getSelectedIndex();
                if (index != -1) {
                    manager.deleteAssignment(index);
                    refreshScreen();
                } else {
                    JOptionPane.showMessageDialog(null, "Please click on a task to delete!");
                }
            }
        });

        btnReport.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String report = reportGenerator.generateReport(manager.getAssignments());
                JOptionPane.showMessageDialog(null, report, "Student Report", JOptionPane.INFORMATION_MESSAGE);
            }
        });

        btnSave.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    fileManager.saveData(manager);
                    JOptionPane.showMessageDialog(null, "Data Saved Successfully!");
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "Error Saving: " + ex.getMessage());
                }
            }
        });

        btnLoad.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    fileManager.loadData(manager);
                    refreshScreen();
                    JOptionPane.showMessageDialog(null, "Data Loaded Successfully!");
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "Error Loading: " + ex.getMessage());
                }
            }
        });
    }

    // --- CUSTOM ADD/EDIT FORM WITH CHECKBOX ---
    private void showTaskForm(Assignment existingTask, int index) {
        JTextField nameField = new JTextField(existingTask != null ? existingTask.getAssignmentName() : "");
        JTextField dateField = new JTextField(existingTask != null ? existingTask.getDueDate() : "");
        
        String[] priorities = {"High", "Medium", "Low"};
        JComboBox<String> priorityBox = new JComboBox<>(priorities);
        JCheckBox completeBox = new JCheckBox("Task is Complete"); // NEW CHECKBOX
        
        if (existingTask != null) {
            priorityBox.setSelectedItem(existingTask.getPriority());
            completeBox.setSelected(existingTask.getIsComplete());
        }

        Object[] message = {
            "Task Name:", nameField,
            "Due Date (e.g., 06-20):", dateField,
            "Priority:", priorityBox,
            "Status:", completeBox
        };

        String title = (existingTask == null) ? "Add New Task" : "Edit Task";
        int option = JOptionPane.showConfirmDialog(this, message, title, JOptionPane.OK_CANCEL_OPTION);

        if (option == JOptionPane.OK_OPTION) {
            String name = nameField.getText().trim();
            String date = dateField.getText().trim();
            String priority = (String) priorityBox.getSelectedItem();
            boolean isDone = completeBox.isSelected(); // Read the checkbox

            if (!name.isEmpty()) {
                if (existingTask == null) {
                    // Adding
                    Course defaultCourse = manager.getCourses().get(0);
                    Assignment newTask = Assignment.addAssignment(name, defaultCourse, date, priority);
                    newTask.setIsComplete(isDone); // Apply status on creation
                    manager.addAssignment(newTask);
                } else {
                    // Editing
                    manager.editAssignment(index, name, date, priority, isDone);
                }
                refreshScreen();
            }
        }
    }

    private void refreshScreen() {
        manager.displayAssignments(listModel);
        dashboardLabel.setText(manager.updateDashboard());
    }
}